"""Ignore-rule engine."""
